# Preprocessing steps
folder_imgs='/home/data/preprocessing/output_folder_for_masked_imgs' # folder with all the imgs to preprocess
ref_img='/home/data/preprocessing/ref.nii.gz'
folder_steps='/home/data/preprocessing/folder_steps_preproc' # folder to save intermediate steps
folder_save='/home/data/preprocessing/folder_preproc_imgs' # folder to save prepcrocessed images

for IMG in $folder_imgs/* ; do sub=${IMG#$folder_imgs/} ; sub=${sub%%.nii.gz} ; echo $sub ; mirtk extract-image-region $folder_imgs/${sub}.nii.gz $folder_steps/${sub}_ext.nii.gz -Rt1 0 -Rt2 0 ; mirtk threshold-image $folder_steps/${sub}_ext.nii.gz $folder_steps/th.nii.gz 0.5 ; mirtk crop-image $folder_steps/${sub}_ext.nii.gz $folder_steps/th.nii.gz  $folder_steps/${sub}_thr.nii.gz ; mirtk edit-image $ref_img $folder_steps/ref-out-edit.nii.gz -copy-origin $folder_steps/${sub}_thr.nii.gz ; mirtk transform-image $folder_steps/${sub}_thr.nii.gz $folder_steps/${sub}_in_ref.nii.gz -target $folder_steps/ref-out-edit.nii.gz -interp Linear ; mirtk crop-image $folder_steps/${sub}_in_ref.nii.gz $folder_steps/th.nii.gz $folder_steps/${sub}.nii.gz ; mirtk nan $folder_steps/${sub}.nii.gz 1000000 ; mirtk pad-3d $folder_steps/${sub}.nii.gz $folder_save/${sub}.nii.gz 256 1 ; done


